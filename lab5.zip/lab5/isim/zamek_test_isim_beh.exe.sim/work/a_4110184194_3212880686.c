/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/lab/Documents/UCiSW-Lab-5-main/lab5/lab5/zamek.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_4110184194_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 1472U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3968);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(49, ng0);
    t3 = (t0 + 1672U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 1992U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 4080);
    t4 = (t1 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t2;
    xsi_driver_first_trans_fast(t1);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(50, ng0);
    t3 = (t0 + 4080);
    t7 = (t3 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)0;
    xsi_driver_first_trans_fast(t3);
    goto LAB6;

}

static void work_a_4110184194_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned char t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    static char *nl0[] = {&&LAB3, &&LAB4, &&LAB5, &&LAB6, &&LAB7, &&LAB8, &&LAB9, &&LAB10, &&LAB11, &&LAB12, &&LAB13, &&LAB14, &&LAB15};

LAB0:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4144);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(62, ng0);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 3984);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(64, ng0);
    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t4 = (t0 + 6653);
    t9 = 1;
    if (8U == 8U)
        goto LAB22;

LAB23:    t9 = 0;

LAB24:    if (t9 == 1)
        goto LAB19;

LAB20:    t8 = (unsigned char)0;

LAB21:    if (t8 != 0)
        goto LAB16;

LAB18:
LAB17:    goto LAB2;

LAB4:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6661);
    t8 = 1;
    if (8U == 8U)
        goto LAB34;

LAB35:    t8 = 0;

LAB36:    if (t8 == 1)
        goto LAB31;

LAB32:    t3 = (unsigned char)0;

LAB33:    if (t3 != 0)
        goto LAB28;

LAB30:
LAB29:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6669);
    t8 = 1;
    if (8U == 8U)
        goto LAB46;

LAB47:    t8 = 0;

LAB48:    if ((!(t8)) == 1)
        goto LAB43;

LAB44:    t3 = (unsigned char)0;

LAB45:    if (t3 != 0)
        goto LAB40;

LAB42:
LAB41:    goto LAB2;

LAB5:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6677);
    t8 = 1;
    if (8U == 8U)
        goto LAB58;

LAB59:    t8 = 0;

LAB60:    if (t8 == 1)
        goto LAB55;

LAB56:    t3 = (unsigned char)0;

LAB57:    if (t3 != 0)
        goto LAB52;

LAB54:
LAB53:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6685);
    t8 = 1;
    if (8U == 8U)
        goto LAB70;

LAB71:    t8 = 0;

LAB72:    if ((!(t8)) == 1)
        goto LAB67;

LAB68:    t3 = (unsigned char)0;

LAB69:    if (t3 != 0)
        goto LAB64;

LAB66:
LAB65:    goto LAB2;

LAB6:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6693);
    t8 = 1;
    if (8U == 8U)
        goto LAB82;

LAB83:    t8 = 0;

LAB84:    if (t8 == 1)
        goto LAB79;

LAB80:    t3 = (unsigned char)0;

LAB81:    if (t3 != 0)
        goto LAB76;

LAB78:
LAB77:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6701);
    t8 = 1;
    if (8U == 8U)
        goto LAB94;

LAB95:    t8 = 0;

LAB96:    if ((!(t8)) == 1)
        goto LAB91;

LAB92:    t3 = (unsigned char)0;

LAB93:    if (t3 != 0)
        goto LAB88;

LAB90:
LAB89:    goto LAB2;

LAB7:    xsi_set_current_line(95, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6709);
    t8 = 1;
    if (8U == 8U)
        goto LAB106;

LAB107:    t8 = 0;

LAB108:    if (t8 == 1)
        goto LAB103;

LAB104:    t3 = (unsigned char)0;

LAB105:    if (t3 != 0)
        goto LAB100;

LAB102:
LAB101:    xsi_set_current_line(98, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6717);
    t8 = 1;
    if (8U == 8U)
        goto LAB118;

LAB119:    t8 = 0;

LAB120:    if ((!(t8)) == 1)
        goto LAB115;

LAB116:    t3 = (unsigned char)0;

LAB117:    if (t3 != 0)
        goto LAB112;

LAB114:
LAB113:    goto LAB2;

LAB8:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6725);
    t8 = 1;
    if (8U == 8U)
        goto LAB130;

LAB131:    t8 = 0;

LAB132:    if (t8 == 1)
        goto LAB127;

LAB128:    t3 = (unsigned char)0;

LAB129:    if (t3 != 0)
        goto LAB124;

LAB126:
LAB125:    xsi_set_current_line(106, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6733);
    t8 = 1;
    if (8U == 8U)
        goto LAB142;

LAB143:    t8 = 0;

LAB144:    if ((!(t8)) == 1)
        goto LAB139;

LAB140:    t3 = (unsigned char)0;

LAB141:    if (t3 != 0)
        goto LAB136;

LAB138:
LAB137:    goto LAB2;

LAB9:    xsi_set_current_line(113, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6741);
    t8 = 1;
    if (8U == 8U)
        goto LAB154;

LAB155:    t8 = 0;

LAB156:    if (t8 == 1)
        goto LAB151;

LAB152:    t3 = (unsigned char)0;

LAB153:    if (t3 != 0)
        goto LAB148;

LAB150:
LAB149:    xsi_set_current_line(116, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6749);
    t8 = 1;
    if (8U == 8U)
        goto LAB166;

LAB167:    t8 = 0;

LAB168:    if ((!(t8)) == 1)
        goto LAB163;

LAB164:    t3 = (unsigned char)0;

LAB165:    if (t3 != 0)
        goto LAB160;

LAB162:
LAB161:    goto LAB2;

LAB10:    xsi_set_current_line(121, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6757);
    t8 = 1;
    if (8U == 8U)
        goto LAB178;

LAB179:    t8 = 0;

LAB180:    if (t8 == 1)
        goto LAB175;

LAB176:    t3 = (unsigned char)0;

LAB177:    if (t3 != 0)
        goto LAB172;

LAB174:
LAB173:    xsi_set_current_line(124, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6765);
    t8 = 1;
    if (8U == 8U)
        goto LAB190;

LAB191:    t8 = 0;

LAB192:    if ((!(t8)) == 1)
        goto LAB187;

LAB188:    t3 = (unsigned char)0;

LAB189:    if (t3 != 0)
        goto LAB184;

LAB186:
LAB185:    goto LAB2;

LAB11:    xsi_set_current_line(129, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6773);
    t8 = 1;
    if (8U == 8U)
        goto LAB202;

LAB203:    t8 = 0;

LAB204:    if (t8 == 1)
        goto LAB199;

LAB200:    t3 = (unsigned char)0;

LAB201:    if (t3 != 0)
        goto LAB196;

LAB198:
LAB197:    xsi_set_current_line(132, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6781);
    t8 = 1;
    if (8U == 8U)
        goto LAB214;

LAB215:    t8 = 0;

LAB216:    if ((!(t8)) == 1)
        goto LAB211;

LAB212:    t3 = (unsigned char)0;

LAB213:    if (t3 != 0)
        goto LAB208;

LAB210:
LAB209:    goto LAB2;

LAB12:    xsi_set_current_line(139, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6789);
    t8 = 1;
    if (8U == 8U)
        goto LAB226;

LAB227:    t8 = 0;

LAB228:    if (t8 == 1)
        goto LAB223;

LAB224:    t3 = (unsigned char)0;

LAB225:    if (t3 != 0)
        goto LAB220;

LAB222:
LAB221:    xsi_set_current_line(143, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6797);
    t9 = 1;
    if (8U == 8U)
        goto LAB241;

LAB242:    t9 = 0;

LAB243:    if ((!(t9)) == 1)
        goto LAB238;

LAB239:    t8 = (unsigned char)0;

LAB240:    if (t8 == 1)
        goto LAB235;

LAB236:    t3 = (unsigned char)0;

LAB237:    if (t3 != 0)
        goto LAB232;

LAB234:
LAB233:    xsi_set_current_line(146, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6813);
    t3 = 1;
    if (8U == 8U)
        goto LAB256;

LAB257:    t3 = 0;

LAB258:    if (t3 != 0)
        goto LAB253;

LAB255:
LAB254:    goto LAB2;

LAB13:    xsi_set_current_line(151, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6821);
    t8 = 1;
    if (8U == 8U)
        goto LAB268;

LAB269:    t8 = 0;

LAB270:    if (t8 == 1)
        goto LAB265;

LAB266:    t3 = (unsigned char)0;

LAB267:    if (t3 != 0)
        goto LAB262;

LAB264:
LAB263:    xsi_set_current_line(154, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6829);
    t8 = 1;
    if (8U == 8U)
        goto LAB280;

LAB281:    t8 = 0;

LAB282:    if ((!(t8)) == 1)
        goto LAB277;

LAB278:    t3 = (unsigned char)0;

LAB279:    if (t3 != 0)
        goto LAB274;

LAB276:
LAB275:    goto LAB2;

LAB14:    xsi_set_current_line(159, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6837);
    t8 = 1;
    if (8U == 8U)
        goto LAB292;

LAB293:    t8 = 0;

LAB294:    if (t8 == 1)
        goto LAB289;

LAB290:    t3 = (unsigned char)0;

LAB291:    if (t3 != 0)
        goto LAB286;

LAB288:
LAB287:    xsi_set_current_line(162, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6845);
    t8 = 1;
    if (8U == 8U)
        goto LAB304;

LAB305:    t8 = 0;

LAB306:    if ((!(t8)) == 1)
        goto LAB301;

LAB302:    t3 = (unsigned char)0;

LAB303:    if (t3 != 0)
        goto LAB298;

LAB300:
LAB299:    goto LAB2;

LAB15:    xsi_set_current_line(169, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB310;

LAB312:
LAB311:    goto LAB2;

LAB16:    xsi_set_current_line(65, ng0);
    t12 = (t0 + 4144);
    t16 = (t12 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)1;
    xsi_driver_first_trans_fast(t12);
    goto LAB17;

LAB19:    t12 = (t0 + 1192U);
    t13 = *((char **)t12);
    t14 = *((unsigned char *)t13);
    t15 = (t14 == (unsigned char)3);
    t8 = t15;
    goto LAB21;

LAB22:    t10 = 0;

LAB25:    if (t10 < 8U)
        goto LAB26;
    else
        goto LAB24;

LAB26:    t7 = (t5 + t10);
    t11 = (t4 + t10);
    if (*((unsigned char *)t7) != *((unsigned char *)t11))
        goto LAB23;

LAB27:    t10 = (t10 + 1);
    goto LAB25;

LAB28:    xsi_set_current_line(70, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)2;
    xsi_driver_first_trans_fast(t7);
    goto LAB29;

LAB31:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB33;

LAB34:    t10 = 0;

LAB37:    if (t10 < 8U)
        goto LAB38;
    else
        goto LAB36;

LAB38:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB35;

LAB39:    t10 = (t10 + 1);
    goto LAB37;

LAB40:    xsi_set_current_line(73, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB41;

LAB43:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB45;

LAB46:    t10 = 0;

LAB49:    if (t10 < 8U)
        goto LAB50;
    else
        goto LAB48;

LAB50:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB47;

LAB51:    t10 = (t10 + 1);
    goto LAB49;

LAB52:    xsi_set_current_line(78, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB53;

LAB55:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB57;

LAB58:    t10 = 0;

LAB61:    if (t10 < 8U)
        goto LAB62;
    else
        goto LAB60;

LAB62:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB59;

LAB63:    t10 = (t10 + 1);
    goto LAB61;

LAB64:    xsi_set_current_line(81, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB65;

LAB67:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB69;

LAB70:    t10 = 0;

LAB73:    if (t10 < 8U)
        goto LAB74;
    else
        goto LAB72;

LAB74:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB71;

LAB75:    t10 = (t10 + 1);
    goto LAB73;

LAB76:    xsi_set_current_line(88, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)4;
    xsi_driver_first_trans_fast(t7);
    goto LAB77;

LAB79:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB81;

LAB82:    t10 = 0;

LAB85:    if (t10 < 8U)
        goto LAB86;
    else
        goto LAB84;

LAB86:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB83;

LAB87:    t10 = (t10 + 1);
    goto LAB85;

LAB88:    xsi_set_current_line(91, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB89;

LAB91:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB93;

LAB94:    t10 = 0;

LAB97:    if (t10 < 8U)
        goto LAB98;
    else
        goto LAB96;

LAB98:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB95;

LAB99:    t10 = (t10 + 1);
    goto LAB97;

LAB100:    xsi_set_current_line(96, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)5;
    xsi_driver_first_trans_fast(t7);
    goto LAB101;

LAB103:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB105;

LAB106:    t10 = 0;

LAB109:    if (t10 < 8U)
        goto LAB110;
    else
        goto LAB108;

LAB110:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB107;

LAB111:    t10 = (t10 + 1);
    goto LAB109;

LAB112:    xsi_set_current_line(99, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB113;

LAB115:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB117;

LAB118:    t10 = 0;

LAB121:    if (t10 < 8U)
        goto LAB122;
    else
        goto LAB120;

LAB122:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB119;

LAB123:    t10 = (t10 + 1);
    goto LAB121;

LAB124:    xsi_set_current_line(104, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)6;
    xsi_driver_first_trans_fast(t7);
    goto LAB125;

LAB127:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB129;

LAB130:    t10 = 0;

LAB133:    if (t10 < 8U)
        goto LAB134;
    else
        goto LAB132;

LAB134:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB131;

LAB135:    t10 = (t10 + 1);
    goto LAB133;

LAB136:    xsi_set_current_line(107, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB137;

LAB139:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB141;

LAB142:    t10 = 0;

LAB145:    if (t10 < 8U)
        goto LAB146;
    else
        goto LAB144;

LAB146:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB143;

LAB147:    t10 = (t10 + 1);
    goto LAB145;

LAB148:    xsi_set_current_line(114, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)7;
    xsi_driver_first_trans_fast(t7);
    goto LAB149;

LAB151:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB153;

LAB154:    t10 = 0;

LAB157:    if (t10 < 8U)
        goto LAB158;
    else
        goto LAB156;

LAB158:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB155;

LAB159:    t10 = (t10 + 1);
    goto LAB157;

LAB160:    xsi_set_current_line(117, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB161;

LAB163:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB165;

LAB166:    t10 = 0;

LAB169:    if (t10 < 8U)
        goto LAB170;
    else
        goto LAB168;

LAB170:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB167;

LAB171:    t10 = (t10 + 1);
    goto LAB169;

LAB172:    xsi_set_current_line(122, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)8;
    xsi_driver_first_trans_fast(t7);
    goto LAB173;

LAB175:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB177;

LAB178:    t10 = 0;

LAB181:    if (t10 < 8U)
        goto LAB182;
    else
        goto LAB180;

LAB182:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB179;

LAB183:    t10 = (t10 + 1);
    goto LAB181;

LAB184:    xsi_set_current_line(125, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB185;

LAB187:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB189;

LAB190:    t10 = 0;

LAB193:    if (t10 < 8U)
        goto LAB194;
    else
        goto LAB192;

LAB194:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB191;

LAB195:    t10 = (t10 + 1);
    goto LAB193;

LAB196:    xsi_set_current_line(130, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)9;
    xsi_driver_first_trans_fast(t7);
    goto LAB197;

LAB199:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB201;

LAB202:    t10 = 0;

LAB205:    if (t10 < 8U)
        goto LAB206;
    else
        goto LAB204;

LAB206:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB203;

LAB207:    t10 = (t10 + 1);
    goto LAB205;

LAB208:    xsi_set_current_line(133, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB209;

LAB211:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB213;

LAB214:    t10 = 0;

LAB217:    if (t10 < 8U)
        goto LAB218;
    else
        goto LAB216;

LAB218:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB215;

LAB219:    t10 = (t10 + 1);
    goto LAB217;

LAB220:    xsi_set_current_line(140, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)10;
    xsi_driver_first_trans_fast(t7);
    goto LAB221;

LAB223:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB225;

LAB226:    t10 = 0;

LAB229:    if (t10 < 8U)
        goto LAB230;
    else
        goto LAB228;

LAB230:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB227;

LAB231:    t10 = (t10 + 1);
    goto LAB229;

LAB232:    xsi_set_current_line(144, ng0);
    t18 = (t0 + 4144);
    t19 = (t18 + 56U);
    t22 = *((char **)t19);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = (unsigned char)0;
    xsi_driver_first_trans_fast(t18);
    goto LAB233;

LAB235:    t7 = (t0 + 1032U);
    t12 = *((char **)t7);
    t7 = (t0 + 6805);
    t20 = 1;
    if (8U == 8U)
        goto LAB247;

LAB248:    t20 = 0;

LAB249:    t3 = (!(t20));
    goto LAB237;

LAB238:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t14 = *((unsigned char *)t11);
    t15 = (t14 == (unsigned char)3);
    t8 = t15;
    goto LAB240;

LAB241:    t10 = 0;

LAB244:    if (t10 < 8U)
        goto LAB245;
    else
        goto LAB243;

LAB245:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB242;

LAB246:    t10 = (t10 + 1);
    goto LAB244;

LAB247:    t21 = 0;

LAB250:    if (t21 < 8U)
        goto LAB251;
    else
        goto LAB249;

LAB251:    t16 = (t12 + t21);
    t17 = (t7 + t21);
    if (*((unsigned char *)t16) != *((unsigned char *)t17))
        goto LAB248;

LAB252:    t21 = (t21 + 1);
    goto LAB250;

LAB253:    xsi_set_current_line(147, ng0);
    t7 = (t0 + 4144);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t16 = *((char **)t13);
    *((unsigned char *)t16) = (unsigned char)1;
    xsi_driver_first_trans_fast(t7);
    goto LAB254;

LAB256:    t10 = 0;

LAB259:    if (t10 < 8U)
        goto LAB260;
    else
        goto LAB258;

LAB260:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB257;

LAB261:    t10 = (t10 + 1);
    goto LAB259;

LAB262:    xsi_set_current_line(152, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)11;
    xsi_driver_first_trans_fast(t7);
    goto LAB263;

LAB265:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB267;

LAB268:    t10 = 0;

LAB271:    if (t10 < 8U)
        goto LAB272;
    else
        goto LAB270;

LAB272:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB269;

LAB273:    t10 = (t10 + 1);
    goto LAB271;

LAB274:    xsi_set_current_line(155, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB275;

LAB277:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB279;

LAB280:    t10 = 0;

LAB283:    if (t10 < 8U)
        goto LAB284;
    else
        goto LAB282;

LAB284:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB281;

LAB285:    t10 = (t10 + 1);
    goto LAB283;

LAB286:    xsi_set_current_line(160, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)12;
    xsi_driver_first_trans_fast(t7);
    goto LAB287;

LAB289:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB291;

LAB292:    t10 = 0;

LAB295:    if (t10 < 8U)
        goto LAB296;
    else
        goto LAB294;

LAB296:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB293;

LAB297:    t10 = (t10 + 1);
    goto LAB295;

LAB298:    xsi_set_current_line(163, ng0);
    t7 = (t0 + 4144);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t16 = (t13 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t7);
    goto LAB299;

LAB301:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t9 = *((unsigned char *)t11);
    t14 = (t9 == (unsigned char)3);
    t3 = t14;
    goto LAB303;

LAB304:    t10 = 0;

LAB307:    if (t10 < 8U)
        goto LAB308;
    else
        goto LAB306;

LAB308:    t5 = (t2 + t10);
    t6 = (t1 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB305;

LAB309:    t10 = (t10 + 1);
    goto LAB307;

LAB310:    xsi_set_current_line(170, ng0);
    t1 = (t0 + 4144);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB311;

}

static void work_a_4110184194_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(176, ng0);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)12);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB5:    t9 = (t0 + 4208);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);

LAB2:    t14 = (t0 + 4000);
    *((int *)t14) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 4208);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB6:    goto LAB2;

}


extern void work_a_4110184194_3212880686_init()
{
	static char *pe[] = {(void *)work_a_4110184194_3212880686_p_0,(void *)work_a_4110184194_3212880686_p_1,(void *)work_a_4110184194_3212880686_p_2};
	xsi_register_didat("work_a_4110184194_3212880686", "isim/zamek_test_isim_beh.exe.sim/work/a_4110184194_3212880686.didat");
	xsi_register_executes(pe);
}
