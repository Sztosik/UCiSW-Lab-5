function showFBApplet(fb) { parent.leftnav.showAppletFB(fb); }
function showFB(fb) { parent.leftnav.showFB(fb); }
function showMC(mc) { parent.leftnav.showAppletMC(mc); }
function showPT(pterm, type) { parent.leftnav.showPterm(pterm, type); }
function showPin(pin) { parent.leftnav.showAppletPin(pin); }
function showEqn(sig) { parent.leftnav.showEqn(sig); }
function showFBDetail(fb) { parent.leftnav.showFB(fb); }
function showLegend(url) { parent.leftnav.showLegend(url, 650, 350); }
function showTop() { parent.leftnav.showTop(); }
